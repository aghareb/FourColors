package com.example.fourcolors;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.view.View;
import java.util.Random;

public class MainActivity extends Activity {
    FrameLayout stage, square, centerSlot;
    View centerCircle;
    TextView feedback;
    int currentColor=-1;
    boolean locked=false;
    final Random random=new Random();
    ToneGenerator tone;
    final int[] colors={0xFF25B765,0xFFE94C58,0xFFFFC83D,0xFF3494F3};
    final int[] tops={0xFF72E39B,0xFFFF9299,0xFFFFE68B,0xFF85C5FF};
    final int[] bottoms={0xFF137D43,0xFFAC2736,0xFFB78100,0xFF155BA8};
    final String[] names={"سبز","قرمز","زرد","آبی"};
    final int[] correct={0,1,2,3};
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    GradientDrawable rounded(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    GradientDrawable gradient(int t,int b,int r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{t,b});d.setCornerRadius(dp(r));d.setStroke(dp(1),0x22000000);return d;}
    GradientDrawable circle(int t,int b){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{t,b});d.setShape(GradientDrawable.OVAL);d.setStroke(dp(1),0x33000000);return d;}
    TextView text(String s,int size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setGravity(Gravity.CENTER);return t;}
    void hideFeedback(){feedback.setText("");feedback.setVisibility(View.GONE);}
    void nextRound(){int n;do{n=random.nextInt(4);}while(n==currentColor);currentColor=n;square.setBackground(gradient(tops[n],bottoms[n],24));square.setElevation(dp(12));centerCircle.setBackground(circle(Color.WHITE,Color.WHITE));hideFeedback();locked=false;}
    void showFeedback(boolean ok){feedback.setText(ok?"✓":"✕");feedback.setTextColor(ok?0xFF20A45A:0xFFE34250);feedback.setVisibility(View.VISIBLE);feedback.setScaleX(.65f);feedback.setScaleY(.65f);feedback.animate().scaleX(1f).scaleY(1f).setDuration(160).start();if(tone!=null)tone.startTone(ok?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_NACK,ok?260:320);}
    @Override public void onCreate(Bundle saved){super.onCreate(saved);tone=new ToneGenerator(AudioManager.STREAM_MUSIC,90);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(dp(22),dp(16),dp(22),dp(22));root.setBackgroundColor(0xFFF2F5FA);
        FrameLayout header=new FrameLayout(this);header.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(55)));TextView title=text("چهار رنگ",22,0xFF26354A);title.setTypeface(null,1);header.addView(title,new FrameLayout.LayoutParams(-2,-1,Gravity.CENTER));TextView exit=text("×",30,0xFF5B6574);exit.setBackground(circle(0xFFFFFFFF,0xFFE3E8EF));exit.setElevation(dp(4));FrameLayout.LayoutParams xp=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.RIGHT|Gravity.CENTER_VERTICAL);header.addView(exit,xp);exit.setOnClickListener(v->finish());root.addView(header);
        TextView hint=text("هم‌رنگ مربع را انتخاب کن",15,0xFF778397);root.addView(hint,new LinearLayout.LayoutParams(-1,dp(42)));
        stage=new FrameLayout(this);stage.setBackground(rounded(0xFFE8EDF5,28));stage.setElevation(dp(2));LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,0,1);stp.setMargins(dp(4),dp(10),dp(4),dp(22));root.addView(stage,stp);
        square=new FrameLayout(this);FrameLayout.LayoutParams sqp=new FrameLayout.LayoutParams(dp(230),dp(230),Gravity.CENTER);stage.addView(square,sqp);
        centerSlot=new FrameLayout(this);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(104),dp(104),Gravity.CENTER);square.addView(centerSlot,cp);centerCircle=new View(this);centerCircle.setBackground(circle(Color.WHITE,Color.WHITE));centerSlot.addView(centerCircle,new FrameLayout.LayoutParams(-1,-1));feedback=text("",48,Color.GREEN);feedback.setTypeface(null,1);feedback.setVisibility(View.GONE);centerSlot.addView(feedback,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER);root.addView(row,new LinearLayout.LayoutParams(-1,dp(112)));
        for(int i=0;i<4;i++){final int index=i;FrameLayout btn=new FrameLayout(this);btn.setBackground(circle(tops[i],bottoms[i]));btn.setElevation(dp(10));TextView label=text("",14,Color.WHITE);btn.addView(label,new FrameLayout.LayoutParams(-1,-1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(68),dp(68));bp.setMargins(dp(8),dp(12),dp(8),dp(12));row.addView(btn,bp);
            btn.setOnClickListener(v->{if(locked)return;centerCircle.setBackground(circle(colors[index],colors[index]));if(index==correct[currentColor]){locked=true;showFeedback(true);square.animate().scaleX(1.04f).scaleY(1.04f).setDuration(90).withEndAction(()->square.animate().scaleX(1f).scaleY(1f).setDuration(90)).start();stage.postDelayed(()->nextRound(),1600);}else{showFeedback(false);stage.postDelayed(()->{if(!locked)hideFeedback();},850);}btn.animate().scaleX(.94f).scaleY(.94f).setDuration(70).withEndAction(()->btn.animate().scaleX(1f).scaleY(1f).setDuration(100)).start();});}
        TextView footer=text("دایره هم‌رنگ مربع را پیدا کن",12,0xFF9AA5B4);root.addView(footer,new LinearLayout.LayoutParams(-1,dp(30)));setContentView(root);nextRound();}
    @Override public void onDestroy(){if(tone!=null)tone.release();super.onDestroy();}
}
