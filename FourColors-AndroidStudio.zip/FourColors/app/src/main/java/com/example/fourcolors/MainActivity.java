package com.example.fourcolors;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    FrameLayout square;
    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    GradientDrawable shape(int color, int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    GradientDrawable circle(int top,int bottom){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom});
        d.setShape(GradientDrawable.OVAL); d.setStroke(dp(1),0x22000000); return d;
    }
    @Override public void onCreate(Bundle saved){ super.onCreate(saved);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(dp(28),dp(28),dp(28),dp(28)); root.setBackgroundColor(0xFFF7F8FA);
        square=new FrameLayout(this); square.setBackground(shape(Color.WHITE,22)); square.setElevation(dp(10));
        FrameLayout.LayoutParams sqp=new FrameLayout.LayoutParams(dp(230),dp(230)); sqp.gravity=Gravity.CENTER;
        FrameLayout holder=new FrameLayout(this); holder.addView(square,sqp);
        root.addView(holder,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER); row.setOrientation(LinearLayout.HORIZONTAL);
        int[] top={0xFF43D477,0xFFFF6868,0xFFFFD34E,0xFF55A9FF};
        int[] bot={0xFF168C46,0xFFC52F3C,0xFFE0A700,0xFF176BC7};
        int[] solid={0xFF22B65A,0xFFE94350,0xFFFFC629,0xFF2589EF};
        for(int i=0;i<4;i++){
            final int c=solid[i]; View b=new View(this); b.setBackground(circle(top[i],bot[i])); b.setElevation(dp(9));
            b.setOnClickListener(v->{ square.setBackground(shape(c,22)); square.animate().scaleX(1.04f).scaleY(1.04f).setDuration(90).withEndAction(()->square.animate().scaleX(1f).scaleY(1f).setDuration(90)).start(); });
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(66),dp(66)); bp.setMargins(dp(9),dp(18),dp(9),dp(18)); row.addView(b,bp);
        }
        root.addView(row,new LinearLayout.LayoutParams(-1,dp(110))); setContentView(root);
    }
}
