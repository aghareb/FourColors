package com.example.fourcolors;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.media.SoundPool;
import android.media.AudioAttributes;

public class MainActivity extends Activity {
    FrameLayout square; SoundPool sounds; int[] soundIds = new int[4];
    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    GradientDrawable rounded(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    GradientDrawable gradient(int top,int bottom,int radius){ GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom}); d.setCornerRadius(dp(radius)); d.setStroke(dp(1),0x22000000); return d; }
    GradientDrawable circle(int top,int bottom){ GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{top,bottom}); d.setShape(GradientDrawable.OVAL); d.setStroke(dp(1),0x33000000); return d; }
    TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    @Override public void onCreate(Bundle saved){ super.onCreate(saved);
        AudioAttributes aa=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        sounds=new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(aa).build();
        soundIds[0]=sounds.load(this,R.raw.green,1); soundIds[1]=sounds.load(this,R.raw.red,1); soundIds[2]=sounds.load(this,R.raw.yellow,1); soundIds[3]=sounds.load(this,R.raw.blue,1);
        int[] colors={0xFF25B765,0xFFE94C58,0xFFFFC83D,0xFF3494F3}; int[] tops={0xFF72E39B,0xFFFF9299,0xFFFFE68B,0xFF85C5FF}; int[] bottoms={0xFF137D43,0xFFAC2736,0xFFB78100,0xFF155BA8};
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(dp(22),dp(16),dp(22),dp(22)); root.setBackgroundColor(0xFFF2F5FA);
        FrameLayout header=new FrameLayout(this); header.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(55)));
        TextView title=text("چهار رنگ",22,0xFF26354A); title.setTypeface(null,1); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-2,-1,Gravity.CENTER); header.addView(title,tp);
        TextView exit=text("×",30,0xFF5B6574); exit.setBackground(circle(0xFFFFFFFF,0xFFE3E8EF)); exit.setElevation(dp(4)); FrameLayout.LayoutParams xp=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.RIGHT|Gravity.CENTER_VERTICAL); header.addView(exit,xp); exit.setOnClickListener(v->finish()); root.addView(header);
        TextView hint=text("یکی از رنگ‌ها را انتخاب کن",15,0xFF778397); root.addView(hint,new LinearLayout.LayoutParams(-1,dp(42)));
        FrameLayout stage=new FrameLayout(this); stage.setBackground(rounded(0xFFE8EDF5,28)); stage.setElevation(dp(2)); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,0,1); stp.setMargins(dp(4),dp(10),dp(4),dp(22)); root.addView(stage,stp);
        square=new FrameLayout(this); square.setBackground(gradient(0xFFFFFFFF,0xFFF5F6F8,24)); square.setElevation(dp(12)); FrameLayout.LayoutParams sqp=new FrameLayout.LayoutParams(dp(230),dp(230),Gravity.CENTER); stage.addView(square,sqp);
        TextView caption=text("",16,0xFFFFFFFF); caption.setTypeface(null,1); square.addView(caption,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); root.addView(row,new LinearLayout.LayoutParams(-1,dp(112)));
        String[] names={"سبز","قرمز","زرد","آبی"};
        for(int i=0;i<4;i++){ final int index=i; FrameLayout btn=new FrameLayout(this); btn.setBackground(circle(tops[i],bottoms[i])); btn.setElevation(dp(10)); TextView label=text("",14,Color.WHITE); btn.addView(label,new FrameLayout.LayoutParams(-1,-1)); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(68),dp(68)); bp.setMargins(dp(8),dp(12),dp(8),dp(12)); row.addView(btn,bp);
            btn.setOnClickListener(v->{ sounds.play(soundIds[index],1f,1f,1,0,1f); square.setBackground(gradient(tops[index],bottoms[index],24)); caption.setText(names[index]); square.animate().scaleX(1.06f).scaleY(1.06f).setDuration(100).withEndAction(()->square.animate().scaleX(1f).scaleY(1f).setDuration(120)).start(); btn.animate().scaleX(.94f).scaleY(.94f).setDuration(70).withEndAction(()->btn.animate().scaleX(1f).scaleY(1f).setDuration(100)).start(); });
        }
        TextView footer=text("با لمس هر دکمه، رنگ مربع تغییر می‌کند",12,0xFF9AA5B4); root.addView(footer,new LinearLayout.LayoutParams(-1,dp(30))); setContentView(root);
    }
    @Override public void onDestroy(){ if(sounds!=null){sounds.release();} super.onDestroy(); }
}
