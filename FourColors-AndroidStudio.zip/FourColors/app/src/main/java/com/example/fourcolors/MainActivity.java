package com.example.fourcolors;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.media.ToneGenerator;
import android.media.AudioManager;
import java.util.Random;

public class MainActivity extends Activity {
 FrameLayout stage, square, centerSlot; View centerShape; TextView feedback; LinearLayout root, optionsRow; int current=0, mode=0; boolean locked=false; Random random=new Random(); ToneGenerator tone;
 final int[] colors={0xFF25B765,0xFFE94C58,0xFFFFC83D,0xFF3494F3}; int fixedColor=0xFF3494F3;
 int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} GradientDrawable bg(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
 TextView txt(String s,int size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setGravity(Gravity.CENTER);return t;}
 void feedback(boolean ok){feedback.setText(ok?"✓":"✕");feedback.setTextColor(ok?0xFF20A45A:0xFFE34250);feedback.setVisibility(View.VISIBLE);feedback.setScaleX(.7f);feedback.setScaleY(.7f);feedback.animate().scaleX(1).scaleY(1).setDuration(140).start();if(tone!=null)tone.startTone(ok?ToneGenerator.TONE_PROP_ACK:ToneGenerator.TONE_PROP_NACK,ok?230:280);}
 void clearFeedback(){feedback.setVisibility(View.GONE);feedback.setText("");}
 void showMode(int m){mode=m;locked=false;clearFeedback();optionsRow.removeAllViews();if(m==0){nextColor();for(int i=0;i<4;i++){final int ix=i;View b=colorButton(colors[i]);optionsRow.addView(b,optionParams());b.setOnClickListener(v->{if(locked)return;centerShape.setBackground(bg(colors[ix],50));if(ix==current){locked=true;feedback(true);stage.postDelayed(()->nextColor(),1400);}else{feedback(false);stage.postDelayed(()->clearFeedback(),700);}});}}
 else{nextShape();for(int i=0;i<4;i++){final int ix=i;ShapeView b=new ShapeView(i,fixedColor,false);optionsRow.addView(b,optionParams());b.setOnClickListener(v->{if(locked)return;centerShape.setBackground(null);((ShapeView)centerShape).setShape(ix);if(ix==current){locked=true;feedback(true);stage.postDelayed(()->nextShape(),1400);}else{feedback(false);stage.postDelayed(()->clearFeedback(),700);}});}}
 }
 LinearLayout.LayoutParams optionParams(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(66),dp(66));p.setMargins(dp(7),dp(8),dp(7),dp(8));return p;}
 View colorButton(int c){View v=new View(this);v.setBackground(bg(c,50));return v;}
 void nextColor(){int n;do{n=random.nextInt(4);}while(n==current);current=n;square.setBackground(bg(colors[current],24));centerShape.setBackground(bg(Color.WHITE,60));clearFeedback();locked=false;}
 void nextShape(){current=random.nextInt(4);square.setBackground(bg(fixedColor,24));((ShapeView)centerShape).setShape(current);clearFeedback();locked=false;}
 @Override public void onCreate(Bundle b){super.onCreate(b);tone=new ToneGenerator(AudioManager.STREAM_MUSIC,85);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(dp(20),dp(12),dp(20),dp(16));root.setBackgroundColor(0xFFF2F5FA);
 FrameLayout header=new FrameLayout(this);header.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(48)));TextView exit=txt("×",30,0xFF5B6574);exit.setBackground(bg(Color.WHITE,30));exit.setElevation(dp(3));FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.RIGHT|Gravity.CENTER_VERTICAL);header.addView(exit,ep);exit.setOnClickListener(v->finish());root.addView(header);
 LinearLayout modeBar=new LinearLayout(this);modeBar.setGravity(Gravity.CENTER);modeBar.setOrientation(LinearLayout.HORIZONTAL);modeBar.setBackground(bg(Color.WHITE,20));modeBar.setElevation(dp(3));TextView colorMode=txt("●",28,0xFF25B765),shapeMode=txt("◆",28,0xFF7C3AED);modeBar.addView(colorMode,new LinearLayout.LayoutParams(0,dp(60),1));modeBar.addView(shapeMode,new LinearLayout.LayoutParams(0,dp(60),1));root.addView(modeBar,new LinearLayout.LayoutParams(-1,dp(60)));colorMode.setOnClickListener(v->showMode(0));shapeMode.setOnClickListener(v->showMode(1));
 stage=new FrameLayout(this);stage.setBackground(bg(0xFFE8EDF5,28));stage.setElevation(dp(2));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,0,1);sp.setMargins(dp(4),dp(12),dp(4),dp(16));root.addView(stage,sp);square=new FrameLayout(this);stage.addView(square,new FrameLayout.LayoutParams(dp(230),dp(230),Gravity.CENTER));centerSlot=new FrameLayout(this);square.addView(centerSlot,new FrameLayout.LayoutParams(dp(110),dp(110),Gravity.CENTER));centerShape=new ShapeView(0,Color.WHITE,false);centerShape.setBackground(bg(Color.WHITE,60));centerSlot.addView(centerShape,new FrameLayout.LayoutParams(-1,-1));feedback=txt("",48,Color.GREEN);feedback.setTypeface(null,1);feedback.setVisibility(View.GONE);centerSlot.addView(feedback,new FrameLayout.LayoutParams(-1,-1));
 optionsRow=new LinearLayout(this);optionsRow.setGravity(Gravity.CENTER);root.addView(optionsRow,new LinearLayout.LayoutParams(-1,dp(92)));setContentView(root);showMode(0);}
 class ShapeView extends View{int shape,color;boolean hollow;Paint p=new Paint(3);ShapeView(int s,int c,boolean h){super(MainActivity.this);shape=s;color=c;hollow=h;}void setShape(int s){shape=s;invalidate();}protected void onDraw(Canvas c){super.onDraw(c);p.setColor(color);p.setStyle(Paint.Style.FILL);float w=getWidth(),h=getHeight(),pad=Math.min(w,h)*.14f;Path path=new Path();switch(shape){case 0:path.addCircle(w/2,h/2,Math.min(w,h)/2-pad,Path.Direction.CW);break;case 1:path.moveTo(w/2,pad);path.lineTo(w-pad,h-pad);path.lineTo(pad,h-pad);path.close();break;case 2:path.addRect(pad,pad,w-pad,h-pad,Path.Direction.CW);break;default:path.moveTo(w/2,pad);path.lineTo(w-pad,h/2);path.lineTo(w/2,h-pad);path.lineTo(pad,h/2);path.close();}c.drawPath(path,p);}}
 @Override public void onDestroy(){if(tone!=null)tone.release();super.onDestroy();}
}
